#!/bin/sh
# Installs only under an explicitly supplied directory. No sudo, unit registration,
# PATH updates, package manager actions, or system configuration changes.
set -eu
if [ "$#" -ne 2 ] || [ "$1" != "--prefix" ]; then
    printf '用法: ./install.sh --prefix /绝对路径/file-relay\n' >&2
    exit 2
fi
case "$2" in
    /*) install_dir=$2 ;;
    *) printf '安装目录必须使用绝对路径\n' >&2; exit 2 ;;
esac
package_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ ! -f "$package_dir/file-relay" ] || [ ! -f "$package_dir/BUILD-INFO.json" ]; then
    printf '请从解压后的发布包内运行此安装脚本\n' >&2
    exit 1
fi
if [ -e "$install_dir" ] || [ -L "$install_dir" ]; then
    printf '为防止覆盖，安装目录必须不存在: %s\n' "$install_dir" >&2
    exit 1
fi
umask 077
mkdir -p -- "$install_dir"
cp -- "$package_dir/file-relay" "$install_dir/file-relay"
chmod 755 "$install_dir/file-relay"
cp -- "$package_dir/README.md" "$package_dir/BUILD-INFO.json" "$package_dir/SHA256SUMS" "$install_dir/"
cp -R -- "$package_dir/docs" "$package_dir/THIRD_PARTY_LICENSES" "$install_dir/"
printf '已安装到: %s\n未注册服务、未修改系统配置。启动命令:\n  "%s/file-relay" start\n' "$install_dir" "$install_dir"
